﻿pyhealth.tasks.mortality_prediction
=======================================


.. automodule:: pyhealth.tasks.mortality_prediction
    :members:
    :undoc-members:
    :show-inheritance: