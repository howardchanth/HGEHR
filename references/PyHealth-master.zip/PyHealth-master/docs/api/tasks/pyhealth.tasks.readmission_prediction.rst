﻿pyhealth.tasks.readmission_prediction
=======================================


.. automodule:: pyhealth.tasks.readmission_prediction
    :members:
    :undoc-members:
    :show-inheritance: