﻿pyhealth.metrics.binary
===================================

.. currentmodule:: pyhealth.metrics.binary

.. autofunction:: binary_metrics_fn