﻿pyhealth.metrics.multiclass
===================================

.. currentmodule:: pyhealth.metrics.multiclass

.. autofunction:: multiclass_metrics_fn

