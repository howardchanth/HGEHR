﻿pyhealth.models.GAMENet
===================================

The separate callable GAMENetLayer and the complete GAMENet model.

.. autoclass:: pyhealth.models.GAMENetLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.GAMENet
    :members:
    :undoc-members:
    :show-inheritance:
