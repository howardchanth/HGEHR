﻿pyhealth.models.GRASP
===================================

The separate callable GRASPLayer and the complete GRASP model.

.. autoclass:: pyhealth.models.GRASPLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.GRASP
    :members:
    :undoc-members:
    :show-inheritance: