﻿pyhealth.models.CNN
===================================

The separate callable CNNLayer and the complete CNN model.

.. autoclass:: pyhealth.models.CNNLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.CNN
    :members:
    :undoc-members:
    :show-inheritance:
