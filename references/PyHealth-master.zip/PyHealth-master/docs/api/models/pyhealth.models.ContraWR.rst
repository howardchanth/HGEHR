﻿pyhealth.models.ContraWR
===================================


The separate callable ResBlock2D and the complete ContraWR model.

.. autoclass:: pyhealth.models.ResBlock2D
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.ContraWR
    :members:
    :undoc-members:
    :show-inheritance: