﻿pyhealth.models.ConCare
===================================

The separate callable ConCareLayer and the complete ConCare model.

.. autoclass:: pyhealth.models.ConCareLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.ConCare
    :members:
    :undoc-members:
    :show-inheritance: