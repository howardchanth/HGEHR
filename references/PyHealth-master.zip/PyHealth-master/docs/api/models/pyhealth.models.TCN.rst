﻿pyhealth.models.TCN
===================================

The separate callable TCNLayer and the complete TCN model.

.. autoclass:: pyhealth.models.TCNLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.TCN
    :members:
    :undoc-members:
    :show-inheritance: