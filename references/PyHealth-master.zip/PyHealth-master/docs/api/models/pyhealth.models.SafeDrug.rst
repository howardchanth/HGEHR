﻿pyhealth.models.SafeDrug
===================================


The separate callable SafeDrugLayer and the complete SafeDrug model.

.. autoclass:: pyhealth.models.SafeDrugLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.SafeDrug
    :members:
    :undoc-members:
    :show-inheritance: