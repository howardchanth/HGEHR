﻿pyhealth.models.MLP
===================================

The separate callable MLP model.

.. autoclass:: pyhealth.models.MLP
    :members:
    :undoc-members:
    :show-inheritance:
