﻿pyhealth.models.Agent
===================================

The separate callable AgentLayer and the complete Agent model.

.. autoclass:: pyhealth.models.AgentLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.Agent
    :members:
    :undoc-members:
    :show-inheritance: