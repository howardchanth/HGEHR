﻿pyhealth.models.AdaCare
===================================

The separate callable AdaCareLayer and the complete AdaCare model.

.. autoclass:: pyhealth.models.AdaCareLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.AdaCare
    :members:
    :undoc-members:
    :show-inheritance: