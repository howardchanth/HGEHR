﻿pyhealth.models.StageNet
===================================

The separate callable StageNetLayer and the complete StageNet model.

.. autoclass:: pyhealth.models.StageNetLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.StageNet
    :members:
    :undoc-members:
    :show-inheritance: