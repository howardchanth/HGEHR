﻿pyhealth.models.Transformer
===================================


The separate callable TransformerLayer and the complete Transformer model.

.. autoclass:: pyhealth.models.TransformerLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.Transformer
    :members:
    :undoc-members:
    :show-inheritance: