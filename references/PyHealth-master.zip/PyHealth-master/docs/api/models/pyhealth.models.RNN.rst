﻿pyhealth.models.RNN
===================================


The separate callable RNNLayer and the complete RNN model.

.. autoclass:: pyhealth.models.RNNLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.RNN
    :members:
    :undoc-members:
    :show-inheritance: