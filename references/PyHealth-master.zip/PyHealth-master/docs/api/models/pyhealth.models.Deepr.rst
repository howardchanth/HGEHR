pyhealth.models.Deepr
===================================

The separate callable DeeprLayer and the complete Deepr model.

.. autoclass:: pyhealth.models.DeeprLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.Deepr
    :members:
    :undoc-members:
    :show-inheritance:
