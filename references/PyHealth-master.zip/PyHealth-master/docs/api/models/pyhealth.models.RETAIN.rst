﻿pyhealth.models.RETAIN
===================================

The separate callable RETAINLayer and the complete RETAIN model.

.. autoclass:: pyhealth.models.RETAINLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.RETAIN
    :members:
    :undoc-members:
    :show-inheritance: