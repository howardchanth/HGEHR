﻿pyhealth.models.MICRON
===================================

The separate callable MICRONLayer and the complete MICRON model.

.. autoclass:: pyhealth.models.MICRONLayer
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: pyhealth.models.MICRON
    :members:
    :undoc-members:
    :show-inheritance: