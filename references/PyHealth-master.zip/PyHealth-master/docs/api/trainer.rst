Trainer
===================================

.. autoclass:: pyhealth.trainer.Trainer
    :members:
    :undoc-members:
    :show-inheritance: