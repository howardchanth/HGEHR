﻿pyhealth.datasets.BaseEHRDataset
===================================

This is the basic EHR dataset class. Any specific EHR dataset will inherit from this class.

.. autoclass:: pyhealth.datasets.BaseEHRDataset
    :members:
    :undoc-members:
    :show-inheritance:

   

   
   
   