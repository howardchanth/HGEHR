﻿pyhealth.datasets.ISRUCDataset
===================================

The open ISRUC EEF database, refer to `doc <https://sleeptight.isr.uc.pt/>`_ for more information. 

.. autoclass:: pyhealth.datasets.ISRUCDataset
    :members:
    :undoc-members:
    :show-inheritance:

   

   
   
   