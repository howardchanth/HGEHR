﻿pyhealth.datasets.SampleEHRDataset
===================================

This class the takes a list of samples as input (either from `BaseEHRDataset.set_task()` or user-provided json input), and provides a uniform interface for accessing the samples.

.. autoclass:: pyhealth.datasets.SampleEHRDataset
    :members:
    :undoc-members:
    :show-inheritance:

   

   
   
   