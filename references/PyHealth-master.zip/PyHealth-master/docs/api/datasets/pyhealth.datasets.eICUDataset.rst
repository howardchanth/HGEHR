﻿pyhealth.datasets.eICUDataset
===================================

The open eICU Collaborative Research Database, refer to `doc <https://eicu-crd.mit.edu/>`_ for more information. We process this database into well-structured dataset object and give user the **best flexibility and convenience** for supporting modeling and analysis.

.. autoclass:: pyhealth.datasets.eICUDataset
    :members:
    :undoc-members:
    :show-inheritance:

   

   
   
   