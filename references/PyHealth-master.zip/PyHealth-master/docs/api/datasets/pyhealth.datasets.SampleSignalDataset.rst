﻿pyhealth.datasets.SampleSignalDataset
===================================

This class the takes a list of samples as input (either from `BaseSignalDataset.set_task()` or user-provided json input), and provides a uniform interface for accessing the samples.

.. autoclass:: pyhealth.datasets.SampleSignalDataset
    :members:
    :undoc-members:
    :show-inheritance:

   

   
   
   