﻿pyhealth.data.Patient
=========================

Another basic data structure in the package. A Patient is a collection of Visit for
the current patients. It contains all necessary attributes of a patient, such as
ethnicity, mortality status, gender, etc. It can support various healthcare tasks.

.. autoclass:: pyhealth.data.Patient
    :members:
    :undoc-members:
    :show-inheritance:
