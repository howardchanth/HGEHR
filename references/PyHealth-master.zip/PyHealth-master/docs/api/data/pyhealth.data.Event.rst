﻿pyhealth.data.Event
=========================

One basic data structure in the package. It is a simple container for a single event. 
It contains all necessary attributes for supporting various healthcare tasks.

.. autoclass:: pyhealth.data.Event
    :members:
    :undoc-members:
    :show-inheritance:
