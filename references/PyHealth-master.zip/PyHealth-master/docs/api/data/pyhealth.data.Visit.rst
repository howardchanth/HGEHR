﻿pyhealth.data.Visit
=========================

Another basic data structure in the package. A Visit is a single encounter in
hospital. It is a container a sequence of Event for each information aspect,
such as diagnosis or medications. It also contains other necessary attributes
for supporting healthcare tasks, such as the date of the visit.

.. autoclass:: pyhealth.data.Visit
    :members:
    :undoc-members:
    :show-inheritance:
