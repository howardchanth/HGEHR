Data
===============

**pyhealth.data** defines the atomic data structures of this package.

.. toctree::
    :maxdepth: 3

    data/pyhealth.data.Event
    data/pyhealth.data.Visit
    data/pyhealth.data.Patient

