About us
========

We are the `SunLab <http://sunlab.org/>`_ healthcare research team at UIUC.

`*Zhenbang Wu <https://zzachw.github.io/>`_ (Ph.D. Student @ University of Illinois Urbana-Champaign)

`*Chaoqi Yang <https://ycq091044.github.io//>`_ (Ph.D. Student @ University of Illinois Urbana-Champaign)

`Patrick Jiang <https://www.linkedin.com/in/patrick-j-3492b4235/>`_ (M.S. Student @ University of Illinois Urbana-Champaign)

`Zhen Lin <https://zlin7.github.io/>`_ (Ph.D. Student @ University of Illinois Urbana-Champaign)

`Jimeng Sun <http://sunlab.org/>`_ (Professor @ University of Illinois Urbana-Champaign)

(* indicates equal contribution)

-----

Acknowledgement
^^^^^^^^^^^^^^^^^^^^

`Yue Zhao <https://www.andrew.cmu.edu/user/yuezhao2/>`_ (Ph.D. Student @ Carnegie Mellon University)

`Dr. Zhi Qiao <https://scholar.google.com/citations?user=20W38KYAAAAJ&hl=en>`_ (Associate ML Director, ACOE @ IQVIA)

`Dr. Xiao Cao <https://sites.google.com/view/danicaxiao/home>`_ (VP of Machine Learning and NLP, Relativity)

`Xiyang Hu <https://www.andrew.cmu.edu/user/xiyanghu/>`_ (Ph.D. Student @ Carnegie Mellon University)